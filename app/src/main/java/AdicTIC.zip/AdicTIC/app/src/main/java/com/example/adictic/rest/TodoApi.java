package com.example.adictic.rest;

public interface TodoApi {
}
