package com.example.adictic.entity;

public class APIError {
    public String msg;

    public APIError() {}

    public APIError(String s) {
        msg = s;
    }

}
